<h1 align="center">Hi 👋, I'm Sakshi</h1>
<h3 align="center">B.Tech Final Year Student at KIIT.</h3>

<div align="center">
  <img alt="Coding" height="300" width="450" 
    src="https://cdn.dribbble.com/users/1364029/screenshots/16093268/media/68e82a7fb4904614a9066d6b540c14b2.gif" alt="image">
</div>

<h2>🌐 Socials:</h2>
<a href="https://www.linkedin.com/in/sakshi1711/">
  <img src="https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white" alt="LinkedIn">
</a>
<a href="https://krsakshi.vercel.app">
  <img src="https://img.shields.io/badge/Website-%230077B5.svg?logo=google-chrome&logoColor=white" alt="Website">
</a>


<h2>About me</h2>
    🌱 I’m currently learning Machine Learning and UI design.
    <br>💻 Currently working on: It's secret! 😯
    <br>💬 Ask me about programming
    <br>📬 Reach me: via Twitter
    <br>⚡ Quote: The future belongs to those who believe in the beauty of their dreams.

<br><br>

<h2 hr="none">❤️Talk to me about:</h2>
    - Machine Learning
    <br>
    - Web Development
    <br>
    - Cloud computing
    <br>
    - Artificial Intelligence
    <br>
    - Graphic Designing
    <br>
    - Frontend Development
<br>
<br>

<h3 align="left">Languages and Tools:</h3>
- <i>Languages:   </i>C, C++, Java, Python, JavaScript, PHP<br>
- <i>Frameworks:  </i> React[in Progress]<br>
- <i>Databases:</i> MySQL<br>
- <i>Web Technologies:</i> HTML, CSS<br>
- <i>Version Control System:</i> Git<br>

<br>
<br>

<p align="left"> 
    <a href="https://www.cprogramming.com/" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> 
    </a> 
   <a href="https://www.w3schools.com/cpp/" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/> 
    </a> 
    <a href="https://www.w3schools.com/css/" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> 
    </a> 
    <a href="https://git-scm.com/" target="_blank" rel="noreferrer">
        <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> 
    </a> 
    <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> 
    </a> 
    <a href="https://www.adobe.com/in/products/illustrator.html" target="_blank" rel="noreferrer">
        <img src="https://www.vectorlogo.zone/logos/adobe_illustrator/adobe_illustrator-icon.svg" alt="illustrator" width="40" height="40"/> 
    </a> 
    <a href="https://www.java.com" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/> 
    </a> 
    <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> 
    </a> 
    <a href="https://www.linux.org/" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg" alt="linux" width="40" height="40"/> 
    </a> 
    <a href="https://www.mysql.com/" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> 
    </a> 
    <a href="https://www.photoshop.com/en" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/photoshop/photoshop-line.svg" alt="photoshop" width="40" height="40"/> 
    </a> 
    <a href="https://www.php.net" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg" alt="php" width="40" height="40"/> 
    </a> 
    <a href="https://www.python.org" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> 
    </a> 
    <a href="https://sass-lang.com" target="_blank" rel="noreferrer">
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/sass/sass-original.svg" alt="sass" width="40" height="40"/> 
    </a> 
</p>
<br>
<br>

<p><img align="left" src="https://github-readme-stats.vercel.app/api/top-langs?username=krsakshi&show_icons=true&locale=en&layout=compact" alt="krsakshi" /></p>

<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=krsakshi&show_icons=true&locale=en" alt="krsakshi" /></p>

<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=krsakshi&" alt="krsakshi" /></p>

<h2>🏆 GitHub Trophies </h2>
<img src="https://github-profile-trophy.vercel.app/?username=krsakshi&theme=gruvbox&no-frame=false&no-bg=false&margin-w=4" alt="GitHub Trophies">

<h2>📈 Contribution Graph</h2>
<img src="https://github-readme-activity-graph.vercel.app/graph?username=krsakshi&bg_color=000000&color=2980b9&line=2980b9&point=27ae60&area_color=2980b9&area=true&hide_border=true" alt="Sakshi Contribution Graph">

<h2>📫 How to reach me:</h2>
<div align="center">
    <a href="mailto:thekrsakshi@gmail.com">
        <img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" alt="Gmail Badge"/>
    </a>

[![](https://visitcount.itsvg.in/api?id=krsakshi&icon=0&color=9)](https://visitcount.itsvg.in)


<h3 align="center"><a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Pixelify+Sans&size=40&duration=2500&pause=500&color=008000&center=true&vCenter=true&random=false&width=647&height=60&lines=Thank+You+for+visiting+!;Hope+to+see+you+again+%F0%9F%98%81;Dont+forget+to+follow!" alt="Typing SVG" /></a></h3>
</div>



